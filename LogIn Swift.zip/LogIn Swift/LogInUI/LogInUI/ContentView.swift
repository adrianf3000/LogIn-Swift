//
//  ContentView.swift
//  LogInUI
//
//  Created by user200111 on 5/13/22.
//

import SwiftUI
import FirebaseAuth

class AppViewModel: ObservableObject{
    
    let auth = Auth.auth()
    
    @Published var signedIn = false
    
    var isSignedIn: Bool{
        return auth.currentUser != nil
    }
    
    func signIn(email: String, password: String){
        auth.signIn(withEmail: email, password: password){[weak self]result,error in
            guard result != nil, error == nil else {
                return
            }
            DispatchQueue.main.async {
                self?.signedIn = true
            }
            
        }
    }
    
    func signUp(email: String, password: String){
        auth.createUser(withEmail: email, password: password){[weak self]result, error in
            guard result != nil, error == nil else {
                return
            }
            DispatchQueue.main.async {
                self?.signedIn = true
            }
            
        }
    }
    func signOut(){
      try? auth.signOut()
        self.signedIn = false
    }
}

struct ContentView: View {
    
    @EnvironmentObject var viewModel: AppViewModel
    
    var body: some View {
        NavigationView{
            
            if viewModel.signedIn{
                
                VStack{
                    Text("You are signed in")
                    Button(action: {
                        viewModel.signOut()
                    }, label: {
                        Text("Sign Out")
                            .frame(width: 300, height: 50)
                            .background(Color.blue)
                            .foregroundColor(Color.white)
                            .padding()
                    })
                }
                
            }
            else{
                SignedInView()
            }
        }
        .onAppear{
            viewModel.signedIn = viewModel.isSignedIn
        }
    }
}
    
    struct SignedInView: View {
        
        @State  var username = ""
        @State  var password = ""
        
        @EnvironmentObject var viewModel: AppViewModel
        
        var body: some View {
                ZStack{
                    Color.blue
                        .ignoresSafeArea()
                    Circle()
                        .scale(1.7)
                        .foregroundColor(.gray)
                    Circle()
                        .scale(1.35)
                        .foregroundColor(.white)
                    
                    VStack {
                        Text("Login")
                            .font(.largeTitle)
                            .bold()
                            .padding()
                        TextField("Username", text: $username)
                            .disableAutocorrection(true)
                            .autocapitalization(.none)
                            .padding()
                            .frame(width: 300, height: 50)
                            .background(Color.black.opacity(0.05))
                            .cornerRadius(10)
                        SecureField("Password", text: $password)
                            .disableAutocorrection(true)
                            .autocapitalization(.none)
                            .padding()
                            .frame(width: 300, height: 50)
                            .background(Color.black.opacity(0.05))
                            .cornerRadius(10)
                        
                        Button(action: {
                            
                            guard !username.isEmpty, !password.isEmpty else {
                                return
                            }
                            
                            viewModel.signIn(email: username, password: password)
                            
                        },label:{
                        Text("LogIn")
                        .foregroundColor(.white)
                        .frame(width:300, height:50)
                        .background(Color.blue)
                        .cornerRadius(10)
                    })
                        NavigationLink("Create account", destination: SignedUpView())
                            .padding()
                }
                .navigationBarHidden(true)
                }
                .navigationTitle("Sign In")
        }
    }

struct SignedUpView: View {
    
    @State  var username = ""
    @State  var password = ""
    
    @EnvironmentObject var viewModel: AppViewModel
    
    var body: some View {
            ZStack{
                Color.blue
                    .ignoresSafeArea()
                Circle()
                    .scale(1.7)
                    .foregroundColor(.gray)
                Circle()
                    .scale(1.35)
                    .foregroundColor(.white)
                
                VStack {
                    Text("Login")
                        .font(.largeTitle)
                        .bold()
                        .padding()
                    TextField("Username", text: $username)
                        .disableAutocorrection(true)
                        .autocapitalization(.none)
                        .padding()
                        .frame(width: 300, height: 50)
                        .background(Color.black.opacity(0.05))
                        .cornerRadius(10)
                    SecureField("Password", text: $password)
                        .disableAutocorrection(true)
                        .autocapitalization(.none)
                        .padding()
                        .frame(width: 300, height: 50)
                        .background(Color.black.opacity(0.05))
                        .cornerRadius(10)
                    
                    Button(action: {
                        
                        guard !username.isEmpty, !password.isEmpty else {
                            return
                        }
                        
                        viewModel.signUp(email: username, password: password)
                        
                    },label:{
                    Text("Create Account")
                    .foregroundColor(.white)
                    .frame(width:300, height:50)
                    .background(Color.blue)
                    .cornerRadius(10)
                })

            }
            .navigationBarHidden(true)
            }
            .navigationTitle("Create account")
    }
}



struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

